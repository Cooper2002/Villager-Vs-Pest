#ifndef ENEMY_H
#define ENEMY_H

#include <QObject>
#include<QPoint>
#include<QPainter>
#include<QPixmap>
class Enemy : public QObject
{
    Q_OBJECT
public:
    Enemy(QPoint sttpos,QPoint tarpos,QString filename,int kind);
    void move();
    void draw(QPainter *painter);
    float life;
    QPoint sttpos;
    QPoint tarpos;
    QPoint curtpos;
    QPixmap pix;
    double speed;
    int damage;
signals:

};

#endif // ENEMY_H
