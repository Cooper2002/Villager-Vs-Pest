#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QPainter>
#include <QPoint>
#include<QImage>
#include <QTimer>
#include"tower.h"
#include<QList>
#include<QDebug>
#include<QFont>
#include<QSound>
#include<QMediaPlayer>
MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    setFixedSize(1024,512);
    setWindowTitle("村民大战害虫");

    QImage title;

   setWindowIcon(QIcon(":/pic2/biene_laufen_r1_b0.png"));

    timer->start(100);

    startmus->setMedia(QUrl("qrc:/mus/Laura Shigihara - Brainiac Maniac.mp3"));
    startmus->setVolume(30);

   connect(ui->b1,&QPushButton::clicked,this,[=](){
       if(money>=500){
       settower1();
       timer2->start(300);
       connect(timer2,&QTimer::timeout,this,[=](){

           MyObj *obj1=new MyObj(QPoint(ui->b1->x(),ui->b1->y()-40),QPoint(1024,240),":/pic2/frost_r0_b0.png",1);
           obj_list.push_back(obj1);
           obj1->move();
           update();

       });
       money=money-500;}
   });


   connect(ui->b2,&QPushButton::clicked,this,[=](){
       if(money>=500){
       settower2();
       timer3->start(500);
               connect(timer3,&QTimer::timeout,this,[=](){
                   MyObj *obj2=new MyObj(QPoint(ui->b2->x(),ui->b2->y()-40),QPoint(1024,240),":/pic2/fire_r0_b0.png",2);
                   obj_list.push_back(obj2);
                   obj2->move();
                   update();
   });
       money=money-500;}});
   connect(ui->b3,&QPushButton::clicked,this,[=](){
       if(money>=500){
       settower3();
       timer4->start(500);
               connect(timer4,&QTimer::timeout,this,[=](){
                   MyObj *obj3=new MyObj(QPoint(ui->b3->x(),ui->b3->y()-120),QPoint(1024,160),":/pic2/godfrost_r0_b0.png",5);
                   obj_list.push_back(obj3);
                   obj3->move();
                   update();
   });
       money=money-500;}});

   connect (ui->upntn,&QPushButton::clicked,this,[=]()
   {if(money>=500){
    uptower1();
    timer5->start(200);
    connect(timer5,&QTimer::timeout,this,[=](){
        MyObj *obj3=new MyObj(QPoint(ui->b1->x(),ui->b1->y()-40),QPoint(1024,240),":/pic2/flash_r0_b0.png",3);
        obj_list.push_back(obj3);
        obj3->move();
        update();
    });
    money=money-500;}
   });
   connect(ui->upbtn2,&QPushButton::clicked,this,[=]()
   {    if(money>=500){
       uptower2();
       timer6->start(400);
       connect(timer6,&QTimer::timeout,this,[=](){
           MyObj *obj4=new MyObj(QPoint(ui->b2->x(),ui->b2->y()-120),QPoint(1024,160),":/pic2/godfire_r0_b0.png",4);
           obj_list.push_back(obj4);
           obj4->move();
           update();});
       money=money-500;}
   });
   connect(ui->upbtn3,&QPushButton::clicked,this,[=]()
   {    if(money>=500){
       uptower3();
       timer7->start(450);
       connect(timer7,&QTimer::timeout,this,[=](){
           MyObj *obj6=new MyObj(QPoint(ui->b2->x(),ui->b2->y()-120),QPoint(1024,160),":/pic2/godfrost_r0_b1.png",6);
           obj_list.push_back(obj6);
           obj6->move();
           update();});
       money=money-500;}
   });
   connect(ui->rembtn1,&QPushButton::clicked,this,[=](){
    timer2->stop();
    timer5->stop();

    foreach(Tower *tower,towerlist)
    {
        if(tower->_tpos.x()==64)
        {
         towerlist.removeOne(tower);
         if(tower->level==1)money=money+400;
         else money=money+800;
        }
    }
   });
   connect(ui->rembtn2,&QPushButton::clicked,this,[=](){
    timer3->stop();
    timer6->stop();
    foreach(Tower *tower,towerlist)
    {
        if(tower->_tpos.x()==96)
        {
         towerlist.removeOne(tower);
         if(tower->level==1)money=money+400;
         else money=money+800;
        }
    }
   });
   connect(ui->rembtn3,&QPushButton::clicked,this,[=](){
    timer4->stop();
    timer7->stop();
    foreach(Tower *tower,towerlist)
    {
        if(tower->_tpos.x()==144)
        {
         towerlist.removeOne(tower);
         if(tower->level==1)money=money+400;
         else money=money+800;
        }
    }
   });
   connect(ui->startbtn,&QPushButton::clicked,[=](){
    startmus->play();
    QTimer::singleShot(100,this,[=]{  Enemy *ene1=new Enemy(QPoint(992,224),QPoint(0,224),":/pic2/biene_laufen_r0_b0.png",1);
   ene_list.push_back(ene1);
   connect(timer,&QTimer::timeout,this,[=](){ene1->move();update();});
   });
    QTimer::singleShot(1400,this,[=]{  Enemy *ene1=new Enemy(QPoint(992,224),QPoint(0,224),":/pic2/biene_laufen_r0_b0.png",1);
   ene_list.push_back(ene1);
   connect(timer,&QTimer::timeout,this,[=](){ene1->move();update();});
   });
    QTimer::singleShot(3000,this,[=]{  Enemy *ene1=new Enemy(QPoint(992,224),QPoint(0,224),":/pic2/biene_laufen_r0_b0.png",1);
   ene_list.push_back(ene1);
   connect(timer,&QTimer::timeout,this,[=](){ene1->move();update();});
   });

   QTimer::singleShot(18000,this,[=]{  Enemy *ene2=new Enemy(QPoint(992,224),QPoint(0,224),":/pic2/feuerfliege_laufen_r0_b0.png",2);
  ene_list.push_back(ene2);
  connect(timer,&QTimer::timeout,this,[=](){ene2->move();update();});
  });
   QTimer::singleShot(20000,this,[=]{  Enemy *ene2=new Enemy(QPoint(992,224),QPoint(0,224),":/pic2/feuerfliege_laufen_r0_b0.png",2);
  ene_list.push_back(ene2);
  connect(timer,&QTimer::timeout,this,[=](){ene2->move();update();});
  });
   QTimer::singleShot(22000,this,[=]{  Enemy *ene2=new Enemy(QPoint(992,224),QPoint(0,224),":/pic2/feuerfliege_laufen_r0_b0.png",2);
  ene_list.push_back(ene2);
  connect(timer,&QTimer::timeout,this,[=](){ene2->move();update();});
  });
   QTimer::singleShot(40000,this,[=]{  Enemy *ene3=new Enemy(QPoint(992,224),QPoint(0,224),":/pic2/fliege_laufen_r0_b0.png",4);
  ene_list.push_back(ene3);
  connect(timer,&QTimer::timeout,this,[=](){ene3->move();update();});
  });
   QTimer::singleShot(43000,this,[=]{  Enemy *ene3=new Enemy(QPoint(992,224),QPoint(0,224),":/pic2/fliege_laufen_r0_b0.png",4);
  ene_list.push_back(ene3);
  connect(timer,&QTimer::timeout,this,[=](){ene3->move();update();});
  });
   QTimer::singleShot(46000,this,[=]{  Enemy *ene3=new Enemy(QPoint(992,224),QPoint(0,224),":/pic2/fliege_laufen_r0_b0.png",4);
  ene_list.push_back(ene3);
  connect(timer,&QTimer::timeout,this,[=](){ene3->move();update();});
  });
   QTimer::singleShot(54000,this,[=]{  Enemy *ene4=new Enemy(QPoint(992,160),QPoint(0,160),":/pic2/tod_laufen_r3_b0.png",3);
  ene_list.push_back(ene4);
  connect(timer,&QTimer::timeout,this,[=](){ene4->move();update();});
  });


});

}
void MainWindow::settower1()
{
    Tower * newtower=new Tower(QPoint(64,224),":/pic2/flash_tower_r0_b1.png");
    towerlist.push_back(newtower);

    update();
}
void MainWindow::settower2()
{
    Tower * newtower=new Tower(QPoint(96,200),":/pic2/fire_tower_r0_b0.png");
    towerlist.push_back(newtower);
    update();
}
void MainWindow::settower3()
{
    Tower * newtower=new Tower(QPoint(144,200),":/pic2/frost_tower_r0_b0.png");
    towerlist.push_back(newtower);
    update();
}
void MainWindow::uptower1()
{   
    timer2->stop();
    foreach(Tower *tower,towerlist)
    {
        if(tower->_tpos.x()==64)
            tower->level=2;}
    update();
}
void MainWindow::uptower2()
{
    timer3->stop();
    foreach(Tower *tower,towerlist)
    {
        if(tower->_tpos.x()==96)
            tower->level=2;}
    update();
}
void MainWindow::uptower3()
{
    timer4->stop();
    foreach(Tower *tower,towerlist)
    {
        if(tower->_tpos.x()==144)
            tower->level=2;}
    update();
}
void MainWindow::showhealth(QPainter *painter)
{   painter->save();
    painter->setPen(Qt::red);
    painter->drawText(QRect(0,100,100,100),QString("血量:%1").arg(health));
    painter->restore();
}
void MainWindow::showsuccess(QPainter *painter)
{
    painter->save();
    painter->setPen(Qt::red);
    painter->drawText(QRect(400,400,200,200),QString("恭喜通过第一关"));
    painter->restore();
}
void MainWindow::showfail(QPainter *painter)
{
    painter->save();
    painter->setPen(Qt::red);
    painter->drawText(QRect(400,400,200,200),QString("抱歉，你未通过第一关"));
    painter->restore();
}
void MainWindow::showmoney(QPainter *painter)
{
    painter->save();
    painter->setPen(Qt::red);
    painter->drawText(QRect(100,100,100,100),QString("钱币：%1").arg(money));
    painter->restore();
}

void MainWindow::paintEvent(QPaintEvent *)
{
    QPainter painter(this);
    QImage pix;
    showhealth(&painter);//展示血量
    showmoney(&painter);

    if(kill==10)
    {
        QSound *victory=new QSound(":/mus2/7041.wav",this);
        startmus->stop();
             victory->play();
             kill++;
    }

    pix.load(":/TileB.png");





    QImage road;
    road=pix.copy(96,64,96,32);
    QImage tree;
    tree=pix.copy(192,128,64,64);
    QImage home;
    home=pix.copy(352,352,64,64);
    painter.drawImage(0,224,home);

for(int i=0;i<=20;i++)
{
    painter.drawImage(96*i+64,224,road);
    painter.drawImage(96*i+64,256,road);
    painter.drawImage(64*i,160,tree);
    painter.drawImage(64*i,288,tree);
}
foreach(Tower *tower,towerlist)
    tower->draw(&painter);
foreach (MyObj *obj,obj_list)
{   if(ene_list.size()!=0){
       if(obj->damage!=0.1&&obj->damage!=0.5){
    if(obj->curtpos.x()<ene_list[0]->curtpos.x())
    obj->draw(&painter);
    else {ene_list[0]->life=ene_list[0]->life-obj->damage;
    obj_list.removeOne(obj);}
       }
       if(obj->damage==0.1||obj->damage==0.5)
       {
           obj->draw(&painter);
           if(obj->curtpos.x()>ene_list[0]->curtpos.x())
           { ene_list[0]->life=ene_list[0]->life-obj->damage;
               foreach(Enemy *ene,ene_list)
                  {if(ene->damage!=4)
                   ene->speed=2;
               else ene->speed=3;}
           }
           if(obj->curtpos.x()>900)
             obj_list.removeOne(obj);

       }qDebug("%f",ene_list[0]->life);
}
if(ene_list.size()==0&&health>=0&&kill!=0)
{showsuccess(&painter);
     //QSound *victory=new QSound(":/mus2/7041.wav",this);
     //victory->play();
}}
foreach(Enemy *ene,ene_list)
 { if(ene->life<0)
   {if(ene->damage!=4)
    money=money+250;
     ene_list.removeOne(ene);
     kill++;
        }
    if(ene->curtpos.x()<100)
      {  ene_list.removeOne(ene);
    health=health-ene->damage;
    if(health<0)
    {
        showfail(&painter);
    }
}}
foreach(Enemy *ene,ene_list)
    ene->draw(&painter);
if(health<0)
{
    showfail(&painter);
}
}
MainWindow::~MainWindow()
{
    delete ui;
}

