#ifndef TOWER_H
#define TOWER_H

#include <QObject>
#include<QPoint>
#include<QPixmap>
#include <QPainter>
class Tower : public QObject
{
    Q_OBJECT
public:
    Tower(QPoint tpos,QString tpixfilename);
    void draw (QPainter *painter);
    QPoint _tpos;
    int level=1;
private:
    //QPoint _tpos;
    QPixmap pixmap;


signals:

};

#endif // TOWER_H
