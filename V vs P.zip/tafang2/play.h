#ifndef ENEMY_H
#define ENEMY_H

#include <QMainWindow>
#include <QWidget>
#include<QPainter>
class Play : public QWidget
{
    Q_OBJECT
public:
    //explicit Enemy(QWidget *parent = nullptr);
   // Enemy(int k,QPainter p);

signals:

};

#endif // ENEMY_H
