#include "tower.h"

Tower::Tower(QPoint tpos,QString tpixfilename) : QObject(0),pixmap(tpixfilename)
{
    _tpos=tpos;
}
void Tower::draw(QPainter *painter)
{
    painter->drawPixmap(_tpos,pixmap);
}
