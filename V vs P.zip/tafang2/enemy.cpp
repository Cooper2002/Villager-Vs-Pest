#include "enemy.h"
#include<QPoint>
#include<QVector2D>
Enemy::Enemy(QPoint sttpos,QPoint tarpos,QString filename,int kind) : QObject(0),pix(filename)
{
    this->curtpos=sttpos;
    this->sttpos=sttpos;
    this->tarpos=tarpos;
    if (kind==1){speed=5;life=130;damage=5;}
    if (kind==2){speed=5  ;life=180;damage=5;}
    if(kind==3){speed=4;life=800,damage=15;}
    if (kind==4){
        speed=6;life=150;damage=4;
    }
}
void Enemy::move()
{
    QVector2D vector(tarpos-sttpos);
    vector.normalize();
    curtpos=curtpos+vector.toPoint()*speed;

}
void Enemy::draw(QPainter *painter)
{
    painter->drawPixmap(curtpos,pix);

}
