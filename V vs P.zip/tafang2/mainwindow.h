#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include "tower.h"
#include"myobj.h"
#include"enemy.h"
#include<QTimer>
#include<QMediaPlayer>
QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = nullptr);
    ~MainWindow();
    void paintEvent(QPaintEvent *);
    int posx=992;
    QList<Tower*>towerlist;
    void settower1();
    void settower2();
    void settower3();
    void uptower1();
    void uptower2();
    void uptower3();
    QTimer *timer=new QTimer(this);
    QTimer *timer2=new QTimer(this);
    QTimer *timer3=new QTimer(this);
    QTimer *timer5=new QTimer(this);
    QTimer *timer6=new QTimer(this);
    QTimer *timer4=new QTimer(this);
    QTimer *timer7=new QTimer(this);
    QList <MyObj*> obj_list;
    QList<Enemy*>ene_list;
    int health=20;
    void showhealth(QPainter*painter);
    void showsuccess(QPainter*painter);
    void showfail(QPainter*painter);
    void showmoney(QPainter*painter);
    void playvicmus();
    int money=1000;
    int kill=0;
    QMediaPlayer * startmus = new QMediaPlayer;
private:
    Ui::MainWindow *ui;
};
#endif // MAINWINDOW_H
